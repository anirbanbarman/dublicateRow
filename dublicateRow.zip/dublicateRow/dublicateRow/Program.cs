﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;

namespace dublicateRow
{
    class Program
    {
        static void Main(string[] args)
        {
            List<object> finalResult = new List<object>();
            JObject obj = JObject.Parse(File.ReadAllText(@"C:\Users\USER\source\repos\dublicateRow\dublicateRow\appComponentList.json"));
            var appCompList = obj.GetValue("appCompList");
           
             foreach (JObject item in appCompList) {
           
                var jsonAttributesValue = item.GetValue("JSONAttributesValue");
                foreach (JObject javk in jsonAttributesValue) {
                 
                    if (javk.GetValue("attribute_code").ToString().ToUpper()=="$URL") {
                        var urlValues = javk.GetValue("value");
                      
                        var urlCount = urlValues.ToString().Split(",").Length;
                        if (urlCount > 1) 
                        {

                             var tempCopmQ = item["ComponentQuery"];
                            foreach (var urlValue in urlValues.ToString().Split(","))
                            {
                               
                                var copyUrl = tempCopmQ;
                                var copyModifieditem = item.DeepClone();
                                copyModifieditem["ComponentQuery"]=copyUrl.ToString().Replace("$URL",urlValue);
                                finalResult.Add(copyModifieditem);
                                
                            }       
                     
                           
                        }
                        else {
                            var tempCopmQ = item["ComponentQuery"];
                            var copyUrl = tempCopmQ;
                            var copyModifieditem = item.DeepClone();
                           copyModifieditem["ComponentQuery"] = copyUrl.ToString().Replace("$URL", urlValues.ToString());
                            finalResult.Add(copyModifieditem);

                        }


                      

                    }
                }



            }
            foreach (var i in finalResult.ToArray())

            {

                Console.WriteLine(i);

            }


        }
    }
}
